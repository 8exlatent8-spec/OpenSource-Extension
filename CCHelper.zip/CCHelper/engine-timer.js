(() => {
    const content = window.__engineContent__;
    const contentWrap = window.__engineContentWrap__;

    if (!content || !contentWrap) {
        console.error("⏱ engine-timer: __engineContent__ not ready");
        return;
    }

    // Always use real (unscaled) timers — game speed must not affect clocks
    const REAL_SET_INTERVAL  = window.__REAL__?.setInterval  ?? setInterval.bind(window);
    const REAL_CLEAR_INTERVAL = window.__REAL__?.clearInterval ?? clearInterval.bind(window);

    // ── Timer Tab ──────────────────────────────────────────────────────────────
    const timerContent = document.createElement("div");
    timerContent.style.display = "none";
    contentWrap.appendChild(timerContent);
    content["Timer"] = timerContent;

    // ── Helpers ────────────────────────────────────────────────────────────────
    function formatTimeMs(totalMs) {
        totalMs = Math.max(0, totalMs);
        const minutes = Math.floor(totalMs / 60000);
        const seconds = Math.floor((totalMs % 60000) / 1000);
        const ms      = Math.floor(totalMs % 1000);
        return `${minutes}:${seconds.toString().padStart(2, "0")}.${ms.toString().padStart(3, "0")}`;
    }

    // ── Timer state ────────────────────────────────────────────────────────────
    let penTimeMs  = 55 * 60000;
    let penInterval = null;
    let bellCount  = 1;
    let running    = false;

    // ── Pen Timer Slider ───────────────────────────────────────────────────────
    const penSliderBox = document.createElement("div");
    penSliderBox.className = "slider-box";

    const penLabel = document.createElement("label");
    penLabel.innerHTML = `Pen Timer <span>${formatTimeMs(penTimeMs)}</span>`;
    const penValue = penLabel.querySelector("span");

    const penSlider = document.createElement("input");
    penSlider.type  = "range";
    penSlider.min   = 1;
    penSlider.max   = 59;
    penSlider.value = 55;

    penSlider.oninput = () => {
        if (running) return;
        penTimeMs = parseInt(penSlider.value) * 60000;
        penValue.textContent = formatTimeMs(penTimeMs);
    };

    penSliderBox.append(penLabel, penSlider);
    timerContent.appendChild(penSliderBox);

    // ── Bell selector + Start button row ──────────────────────────────────────
    const timerButtonRow = document.createElement("div");
    timerButtonRow.className = "button-row";
    timerContent.appendChild(timerButtonRow);

    const bellWrapper = document.createElement("div");
    bellWrapper.style.cssText = "display:flex;align-items:center;gap:6px;flex:0.5;";

    const bellIcon = document.createElement("span");
    bellIcon.textContent  = "🔔";
    bellIcon.style.fontSize = "14px";

    const bellSelect = document.createElement("select");
    bellSelect.style.cssText = "width:100%;color:white;border:none;border-radius:6px;padding:4px;background-color:#222;";

    for (let i = 1; i <= 10; i++) {
        const o = document.createElement("option");
        o.value       = i;
        o.textContent = ` ${i} `;
        o.style.color = "white";
        bellSelect.appendChild(o);
    }
    bellSelect.value    = 1;
    bellSelect.onchange = () => (bellCount = parseInt(bellSelect.value));

    bellWrapper.append(bellIcon, bellSelect);
    timerButtonRow.appendChild(bellWrapper);

    const startBtn = document.createElement("button");
    startBtn.textContent = "Start";
    startBtn.className = "engine-btn enabled";
    startBtn.style.cssText = "flex:1;background:rgba(0,50,0,0.9);";
    timerButtonRow.appendChild(startBtn);

    // ── Bell sound ─────────────────────────────────────────────────────────────
    const bell = new Audio("https://actions.google.com/sounds/v1/alarms/bell_ring.ogg");

    // ── Timer popup ────────────────────────────────────────────────────────────
    function timerPopup(text) {
        const p = document.createElement("div");
        p.className = "engine-notif";
        p.textContent = text;
        p.style.cssText += "background:rgba(50,0,0,0.9);font-size:14px;padding:14px 22px;";
        document.body.appendChild(p);
        setTimeout(() => { p.style.top = "30px"; p.style.opacity = "1"; }, 50);
        setTimeout(() => {
            p.style.opacity = "0";
            p.style.top = "-60px";
            setTimeout(() => p.remove(), 600);
        }, 5000);
    }

    // ── Start / Reset logic ────────────────────────────────────────────────────
    startBtn.onclick = () => {
        if (!running) {
            running = true;
            startBtn.textContent    = "Reset";
            startBtn.style.background = "rgba(50,0,0,0.9)";
            penSlider.disabled      = true;
            penSlider.classList.add("slider-rolling");

            let lastTick = Date.now();
            penInterval  = REAL_SET_INTERVAL(() => {
                const now   = Date.now();
                const delta = now - lastTick;
                lastTick    = now;
                penTimeMs  -= delta;

                penSlider.value      = Math.ceil(penTimeMs / 60000);
                penValue.textContent = formatTimeMs(penTimeMs);

                if (penTimeMs <= 0) {
                    REAL_CLEAR_INTERVAL(penInterval);
                    running = false;
                    timerPopup("⏰ Timer is up!");
                    for (let i = 0; i < bellCount; i++) {
                        setTimeout(() => bell.play(), i * 500);
                    }
                    startBtn.textContent      = "Start";
                    startBtn.style.background = "rgba(0,50,0,0.9)";
                    penSlider.disabled        = false;
                    penSlider.classList.remove("slider-rolling");
                    penTimeMs      = 55 * 60000;
                    penSlider.value      = 55;
                    penValue.textContent = formatTimeMs(penTimeMs);
                }
            }, 50);
        } else {
            REAL_CLEAR_INTERVAL(penInterval);
            running        = false;
            penTimeMs      = 55 * 60000;
            penValue.textContent = formatTimeMs(penTimeMs);
            penSlider.value      = 55;
            penSlider.disabled   = false;
            startBtn.textContent      = "Start";
            startBtn.style.background = "rgba(0,50,0,0.9)";
            penSlider.classList.remove("slider-rolling");
        }
    };

    // ── Stopwatch (in a slider-box container) ─────────────────────────────────
    const swBox = document.createElement("div");
    swBox.className = "slider-box";
    timerContent.appendChild(swBox);

    const swTitleLabel = document.createElement("label");
    swTitleLabel.style.cssText = "justify-content:center;font-size:11px;letter-spacing:0.5px;text-transform:uppercase;opacity:0.6;";
    swTitleLabel.textContent = "Stopwatch";
    swBox.appendChild(swTitleLabel);

    const swDisplay = document.createElement("div");
    swDisplay.textContent = "0:00.000";
    Object.assign(swDisplay.style, {
        fontFamily:    "monospace",
        fontSize:      "22px",
        fontWeight:    "bold",
        textAlign:     "center",
        letterSpacing: "1px",
        padding:       "4px 0 6px",
        color:         "white",
    });
    swBox.appendChild(swDisplay);

    const swBtnRow = document.createElement("div");
    swBtnRow.className = "button-row";
    swBtnRow.style.marginBottom = "0";
    swBox.appendChild(swBtnRow);

    const swStartStopBtn = document.createElement("button");
    swStartStopBtn.textContent   = "Start";
    swStartStopBtn.className     = "engine-btn";
    swStartStopBtn.style.cssText = "flex:1;background:rgba(0,50,0,0.9);";

    const swResetBtn = document.createElement("button");
    swResetBtn.textContent   = "Reset";
    swResetBtn.className     = "engine-btn";
    swResetBtn.style.cssText = "flex:0.5;background:rgba(50,0,0,0.9);";

    swBtnRow.append(swStartStopBtn, swResetBtn);

    let swRunning   = false;
    let swElapsedMs = 0;
    let swLastTick  = null;
    let swInterval  = null;

    function swRender() {
        const m  = Math.floor(swElapsedMs / 60000);
        const s  = Math.floor((swElapsedMs % 60000) / 1000);
        const ms = Math.floor(swElapsedMs % 1000);
        swDisplay.textContent = `${m}:${s.toString().padStart(2,"0")}.${ms.toString().padStart(3,"0")}`;
    }

    swStartStopBtn.onclick = () => {
        if (!swRunning) {
            swRunning  = true;
            swLastTick = Date.now();
            swStartStopBtn.textContent    = "Stop";
            swStartStopBtn.style.background = "rgba(120,60,0,0.9)";
            swInterval = REAL_SET_INTERVAL(() => {
                const now   = Date.now();
                swElapsedMs += now - swLastTick;
                swLastTick   = now;
                swRender();
            }, 30);
        } else {
            swRunning = false;
            REAL_CLEAR_INTERVAL(swInterval);
            swInterval = null;
            swStartStopBtn.textContent    = "Start";
            swStartStopBtn.style.background = "rgba(0,50,0,0.9)";
        }
    };

    swResetBtn.onclick = () => {
        swRunning  = false;
        REAL_CLEAR_INTERVAL(swInterval);
        swInterval  = null;
        swElapsedMs = 0;
        swLastTick  = null;
        swStartStopBtn.textContent    = "Start";
        swStartStopBtn.style.background = "rgba(0,50,0,0.9)";
        swRender();
    };

    console.log("⏱ engine-timer loaded");
})();